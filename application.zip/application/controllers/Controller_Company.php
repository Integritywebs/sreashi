<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_Company extends Admin_Controller 
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		$this->data['page_title'] = 'Company';

		$this->load->model('model_Company');
	}

    /* 
    * It redirects to the company page and displays all the company information
    * It also updates the company information into the database if the 
    * validation for each input field is successfully valid
	*/
	public function index()
	{
		if(!in_array('viewCompany', $this->permission)) {
			// redirect('dashboard', 'refresh');
		 }

		$company_data = $this->model_Company->getCompanyData();

		$result = array();
		foreach ($company_data as $k => $v) {

			$result[$k]['company_info'] = $v;

				}

		$this->data['company_data'] = $result;

		$this->render_template('company/index', $this->data);
	}
	public function edit()
	{  
        if(!in_array('updateCompany', $this->permission)) {
            redirect('dashboard', 'refresh');
        }
        
		$this->form_validation->set_rules('company_name', 'Company name', 'trim|required');
		$this->form_validation->set_rules('service_charge_value', 'Charge Amount', 'trim|integer');
		$this->form_validation->set_rules('vat_charge_value', 'Vat Charge', 'trim|integer');
		$this->form_validation->set_rules('address', 'Address', 'trim|required');
		$this->form_validation->set_rules('message', 'Message', 'trim|required');
	
	
        if ($this->form_validation->run() == TRUE) {
            // true case

        	$data = array(
        		'company_name' => $this->input->post('company_name'),
        		'service_charge_value' => $this->input->post('service_charge_value'),
        		'vat_charge_value' => $this->input->post('vat_charge_value'),
        		'address' => $this->input->post('address'),
        		'phone' => $this->input->post('phone'),
        		'country' => $this->input->post('country'),
        		'message' => $this->input->post('message'),
                'currency' => $this->input->post('currency')
        	);



        	$update = $this->model_Company->update($data, 1);
        	if($update == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Company/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Company/index', 'refresh');
        	}
        }
        else {

            // false case
            
            
            $this->data['currency_symbols'] = $this->currency();
        	$this->data['company_data'] = $this->model_Company->getCompanyData(1);
			$this->render_template('company/edit', $this->data);			
        }	

		
	}
	
	public function create()
	{
        // echo 'came';
        // exit();
		if(!in_array('createCompany', $this->permission)) {
        //     redirect('dashboard', 'refresh');
         }

		$this->form_validation->set_rules('company_code', 'company code', 'trim|required');
		$this->form_validation->set_rules('company_name', 'company name', 'trim|required');
	
		// $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
		$this->form_validation->set_rules('company_local_name', 'company local name', 'trim|required');
		$this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
        $this->form_validation->set_rules('phno', 'Phone no', 'trim|required');
		$this->form_validation->set_rules('faxno', 'Faxno', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
            // true case
        	$upload_image = $this->upload_image();

        	$data = array(
				
				'company_code'=>$this->input->post('company_code'),
        		'company_name' => $this->input->post('company_name'),
        		// 'sku' => $this->input->post('sku'),
        		'company_local_name' => $this->input->post('company_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				'logo' => $upload_image,
        		
				
        	);

        	$create = $this->model_Company->create($data);
        	if($create == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Company/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Company/create', 'refresh');
        	}
        }
        else {
            // false case

        	// attributes 
        	
            $this->render_template('company/create', $this->data);
        }	
	}

    /*
    * This function is invoked from another function to upload the image into the assets folder
    * and returns the image path
    */
	public function upload_image()
    {
    	// assets/images/product_image
        $config['upload_path'] = 'assets/images/logo_image';
        $config['file_name'] =  uniqid();
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '1000';

        // $config['max_width']  = '1024';s
        // $config['max_height']  = '768';

        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('log_image'))
        {
            $error = $this->upload->display_errors();
            return $error;
        }
        else
        {
            $data = array('upload_data' => $this->upload->data());
            $type = explode('.', $_FILES['logo_image']['name']);
            $type = $type[count($type) - 1];
            
            $path = $config['upload_path'].'/'.$config['file_name'].'.'.$type;
            return ($data == true) ? $path : false;            
        }
	}
	public function delete($id)
	{
		if(!in_array('deleteCompany', $this->permission)) {
			redirect('dashboard', 'refresh');
		}

		if($id) {
			if($this->input->post('confirm')) {
					$delete = $this->model_Company->delete($id);
					if($delete == true) {
		        		$this->session->set_flashdata('success', 'Successfully removed');
		        		redirect('Controller_Company/', 'refresh');
		        	}
		        	else {
		        		$this->session->set_flashdata('error', 'Error occurred!!');
		        		redirect('Controller_Company/delete/'.$id, 'refresh');
		        	}

			}	
			else {
				$this->data['id'] = $id;
				$this->render_template('company/delete', $this->data);
			}	
		}
	}
}
