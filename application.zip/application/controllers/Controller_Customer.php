<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Controller_Customer extends Admin_Controller 
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		$this->data['page_title'] = 'Customer';

		$this->load->model('model_mCustomer');
	}

    /* 
    * It redirects to the company page and displays all the company information
    * It also updates the company information into the database if the 
    * validation for each input field is successfully valid
	*/
	public function index()
	{
		if(!in_array('viewBrand', $this->permission)) {
		   redirect('dashboard', 'refresh');
		 }

		$customer_data = $this->model_mCustomer->getCustomerData();

		$result = array();
		foreach ($customer_data as $k => $v) {

			$result[$k]['customer_info'] = $v;

				}

		$this->data['customer_data'] = $result;

		$this->render_template('customer/index', $this->data);
    }
    public function fetchBrandData()
	{
		$result = array('data' => array());

		$data = $this->model_mCustomer->getCustomerData();
    

		foreach ($data as $key => $value) {

           // button
            $buttons = '';
            if(in_array('updateBrand', $this->permission)) {
    			$buttons .= '<a href="'.base_url('Controller_Customer/update/'.$value['id']).'" class="btn btn-warning btn-sm"><i class="fa fa-pencil"></i></a>';
            }

            if(in_array('deleteBrand', $this->permission)) { 
    			$buttons .= ' <button type="button" class="btn btn-danger btn-sm" onclick="removeFunc('.$value['id'].')" data-toggle="modal" data-target="#removeModal"><i class="fa fa-trash"></i></button>';
            }
			

			$img = '<img src="'.base_url($value['logo']).'" alt="'.$value['name'].'" class="img-circle" width="50" height="50" />';

           
           

			$result['data'][$key] = array(
				
				// $value['sku'],
				$value['brand_code'],
				$value['brand_name'],
                $value['phno'] ,
        
                $value['phno'] ,
        
				$buttons
			);
		} // /foreach

		echo json_encode($result);
	}	

    public function create()
	{
        // echo 'came';
        // exit();
		if(!in_array('createBrand', $this->permission)) {
        //     redirect('dashboard', 'refresh');
         }

		$this->form_validation->set_rules('brand_code', 'brand code', 'trim|required');
		$this->form_validation->set_rules('brand_name', 'brand name', 'trim|required');
	
		// $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
		$this->form_validation->set_rules('brand_local_name', 'brand local name', 'trim|required');
		$this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
        $this->form_validation->set_rules('phno', 'Phone no', 'trim|required');
		$this->form_validation->set_rules('faxno', 'Faxno', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
            // true case
        	$upload_image = $this->upload_image();

        	$data = array(
				
				'brand_code'=>$this->input->post('brand_code'),
        		'brand_name' => $this->input->post('brand_name'),
        		// 'sku' => $this->input->post('sku'),
        		'brand_local_name' => $this->input->post('brand_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				'logo' => $upload_image,
        		
				
        	);

        	$create = $this->model_mCustomer->create($data);
        	if($create == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Customer/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Customer/create', 'refresh');
        	}
        }
        else {
            // false case

        	// attributes 
        	
            $this->render_template('customer/create', $this->data);
        }	
	}
	public function addperson()
	{
        // echo 'came';
        // exit();
		if(!in_array('createBrand', $this->permission)) {
        //     redirect('dashboard', 'refresh');
         }

		$this->form_validation->set_rules('brand_code', 'brand code', 'trim|required');
		$this->form_validation->set_rules('brand_name', 'brand name', 'trim|required');
	
		// $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
		$this->form_validation->set_rules('brand_local_name', 'brand local name', 'trim|required');
		$this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
        $this->form_validation->set_rules('phno', 'Phone no', 'trim|required');
		$this->form_validation->set_rules('faxno', 'Faxno', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
            // true case
        	$upload_image = $this->upload_image();

        	$data = array(
				
				'brand_code'=>$this->input->post('brand_code'),
        		'brand_name' => $this->input->post('brand_name'),
        		// 'sku' => $this->input->post('sku'),
        		'brand_local_name' => $this->input->post('brand_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				'logo' => $upload_image,
        		
				
        	);

        	$addperson = $this->model_mCustomer->addperson($data);
        	if($addperson == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Customer/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Customer/create', 'refresh');
        	}
        }
        else {
            // false case

        	// attributes 
        	
            $this->render_template('customer/addperson', $this->data);
        }	
	}

	public function customer_followup()
	{
        // echo 'came';
        // exit();
		if(!in_array('createBrand', $this->permission)) {
        //     redirect('dashboard', 'refresh');
         }

		$this->form_validation->set_rules('brand_code', 'brand code', 'trim|required');
		$this->form_validation->set_rules('brand_name', 'brand name', 'trim|required');
	
		// $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
		$this->form_validation->set_rules('brand_local_name', 'brand local name', 'trim|required');
		$this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
        $this->form_validation->set_rules('phno', 'Phone no', 'trim|required');
		$this->form_validation->set_rules('faxno', 'Faxno', 'trim|required');
		
	
        if ($this->form_validation->run() == TRUE) {
            // true case
        	$upload_image = $this->upload_image();

        	$data = array(
				
				'brand_code'=>$this->input->post('brand_code'),
        		'brand_name' => $this->input->post('brand_name'),
        		// 'sku' => $this->input->post('sku'),
        		'brand_local_name' => $this->input->post('brand_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				'logo' => $upload_image,
        		
				
        	);

        	$addperson = $this->model_mCustomer->addperson($data);
        	if($addperson == true) {
        		$this->session->set_flashdata('success', 'Successfully created');
        		redirect('Controller_Customer/', 'refresh');
        	}
        	else {
        		$this->session->set_flashdata('errors', 'Error occurred!!');
        		redirect('Controller_Customer/create', 'refresh');
        	}
        }
        else {
            // false case

        	// attributes 
        	
            $this->render_template('customer/customer_followup', $this->data);
        }	
	}
 /*
    * This function is invoked from another function to upload the image into the assets folder
    * and returns the image path
    */
	public function update($customer_id)
	{      
        if(!in_array('updateBrand', $this->permission)) {
            // redirect('dashboard', 'refresh');
        }

        if(!$customer_id) {
            // redirect('dashboard', 'refresh');
        }

        $this->form_validation->set_rules('product_name', 'Product name', 'trim|required');
        // $this->form_validation->set_rules('sku', 'SKU', 'trim|required');
        $this->form_validation->set_rules('price', 'Price', 'trim|required');
        $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
        $this->form_validation->set_rules('store', 'Store', 'trim|required');
        $this->form_validation->set_rules('availability', 'Availability', 'trim|required');

        if ($this->form_validation->run() == TRUE) {
            // true case
            
            $data = array(
                'brand_code'=>$this->input->post('brand_code'),
        		'brand_name' => $this->input->post('brand_name'),
        		// 'sku' => $this->input->post('sku'),
        		'brand_local_name' => $this->input->post('brand_local_name'),
        		'manager_name' => $this->input->post('manager_name'),
        		'phno' => $this->input->post('phno'),
        		'faxno' => $this->input->post('faxno'),
				'addrs1' => $this->input->post('addrs1'),
				'addrs2' => $this->input->post('addrs2'),
				'email' => $this->input->post('email'),
				'website' => $this->input->post('website'),
				  );

            
           
            $update = $this->model_mCustomer->update($data, $customer_id);
            if($update == true) {
                $this->session->set_flashdata('success', 'Successfully updated');
                redirect('Controller_Customer/', 'refresh');
            }
            else {
                $this->session->set_flashdata('errors', 'Error occurred!!');
                redirect('Controller_Customer/update/'.$customer_id, 'refresh');
            }
        }
       
            $customer_data = $this->model_mCustomer->getCustomerData($customer_id);
            $this->data['customer_data'] = $customer_data;
            $this->render_template('customer/edit', $this->data); 
        }   
	

    /*
    * It removes the data from the database
    * and it returns the response into the json format
    */
	public function delete($id)
	{
		if(!in_array('deleteBrand', $this->permission)) {
			redirect('dashboard', 'refresh');
		}

		if($id) {
			if($this->input->post('confirm')) {
					$delete = $this->model_mCustomer->delete($id);
					if($delete == true) {
		        		$this->session->set_flashdata('success', 'Successfully removed');
		        		redirect('Controller_Customer/', 'refresh');
		        	}
		        	else {
		        		$this->session->set_flashdata('error', 'Error occurred!!');
		        		redirect('Controller_Customer/delete/'.$id, 'refresh');
		        	}

			}	
			else {
				$this->data['id'] = $id;
				$this->render_template('customer/delete', $this->data);
			}	
		}
	}
}

