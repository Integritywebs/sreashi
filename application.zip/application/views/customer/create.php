
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>var $j = jQuery.noConflict(true);</script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">




<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Add New Customer
      
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Customer</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-md-12 col-xs-12">

        <div id="messages"></div>

        <?php if($this->session->flashdata('success')): ?>
          <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $this->session->flashdata('success'); ?>
          </div>
        <?php elseif($this->session->flashdata('error')): ?>
          <div class="alert alert-error alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php endif; ?>


        <div class="box">
         
          <!-- /.box-header -->
          <form role="form" action="<?php base_url('users/create') ?>" method="post" enctype="multipart/form-data">
              <div class="box-body">

                <?php echo validation_errors(); ?>

                <div class="form-group">


<div class="">
    </div>
</div>

<div class="form-group">
                  <label for="brand_code">Customer ID</label>
                  <input type="text" class="form-control" id="brand_code" name="brand_code" placeholder="Enter company code" autocomplete="off"/>
                </div>

                <div class="form-group">
                  <label for="brand_name">English Name</label>
                  <input type="text" class="form-control" id="brand_name" name="brand_name" placeholder="Enter company name" autocomplete="off"/>
                </div>
                <div class="form-group">
                  <label for="brand_local_name">Local Name</label>
                  <input type="text" class="form-control" id="brand_local_name" name="brand_local_name" placeholder="Enter company local name" autocomplete="off"/>
                </div>
                <div class="form-group">
                  <label for="manager_name">Contact Person</label>
                  <input type="text" class="form-control" id="manager_name" name="manager_name" placeholder="Enter manager name" autocomplete="off"/>
                </div>
                <div class="form-group">
                  <label for="manager_name">Civil ID</label>
                  <input type="text" class="form-control" id="manager_name" name="manager_name" placeholder="Enter manager name" autocomplete="off"/>
                </div>


                <!-- <div class="form-group"> -->
                  <!-- <label for="sku">SKU</label> -->
                  <!-- <input type="text" class="form-control" id="sku" name="sku" placeholder="Enter sku" autocomplete="off" /> -->
                <!-- </div> -->
                <div class="form-group">
                  <label for="phno">Mobile No</label>
                  <input type="text" class="form-control" id="phno" name="phno" placeholder="Enter Phone" autocomplete="off" />
                </div>

              
                <div class="form-group">
                  <label for="phno">Telephone</label>
                  <input type="text" class="form-control" id="phno" name="phno" placeholder="Enter Phone" autocomplete="off" />
                </div>

                <div class="form-group">
                  <label for="faxno">Fax no.</label>
                  <input type="text" class="form-control" id="faxno" name="faxno" placeholder="Enter Faxno" autocomplete="off" />
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" autocomplete="off"/>
                </div>
                
                <div class="form-group">
                  <label for="email">Email 2</label>
                  <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" autocomplete="off"/>
                </div>
                
                <div class="form-group">
                  <label for="addrs1">Address-1</label>
                  <input type="text" class="form-control" id="addrs1" name="addrs1" placeholder="Enter Address " autocomplete="off"/>
                </div>
                <div class="form-group">
                  <label for="addrs2"> Delivery Address-</label>
                  <input type="text" class="form-control" id="addrs2" name="addrs2" placeholder="Enter Address" autocomplete="off"/>
                </div>

                <div class="form-group">
                  <label for="website">Sales Person</label>
                  <input type="text" class="form-control" id="website" name="website" placeholder="Enter Website" autocomplete="off"/>
                </div>

                <div class="form-group">
                  <label for="website">Price Level</label>
                  <input type="text" class="form-control" id="website" name="website" placeholder="Enter Website" autocomplete="off"/>
                </div>


                
                <div class="form-group">
                  <label for="store">Business Type</label>
                  <select class="form-control" id="availability" name="availability">
                    <option value="1">Default Company Name</option>
                   </select>
                </div>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="<?php echo base_url('Controller_Customer/') ?>" class="btn btn-warning">Back</a>
              </div>
            </form>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- col-md-12 -->
    </div>
    <!-- /.row -->
    

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script type="text/javascript">
  $(document).ready(function() {
    $(".select_group").select2();
    $("#description").wysihtml5();

    $("#brandNav").addClass('active');
    $("#brandNav").addClass('active');
    
   
</script>

<script type="text/javascript" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>