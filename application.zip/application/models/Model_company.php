<?php 

class Model_company extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	/* get the brand data */
	public function getCompanyData($companyId = null)
	{
	
		if($companyId) {
			$sql = "SELECT * FROM m_company where id = ?";
			$query = $this->db->query($sql, array($companyId));
			return $query->row_array();
		}

		$sql = "SELECT * FROM m_company ORDER BY id DESC";
		$query = $this->db->query($sql);
		return $query->result_array();
	
	}
	public function create($data)
	{
		if($data) {
			$insert = $this->db->insert('m_company', $data);
			return ($insert == true) ? true : false;
		}
	}
	public function update($data, $id)
	{
		if($data && $id) {
			$this->db->where('id', $id);
			$update = $this->db->update('m_company', $data);
			return ($update == true) ? true : false;
		}
	}
	public function delete($id)
	{
		$this->db->where('id', $id);
		$delete = $this->db->delete('m_company');
		return ($delete == true) ? true : false;
	}



}